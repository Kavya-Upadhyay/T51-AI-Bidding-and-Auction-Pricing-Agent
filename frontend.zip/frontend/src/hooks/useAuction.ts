// src/hooks/useAuction.ts
import { useState, useEffect, useCallback } from 'react';
import { Auction, AIAgent, Bid } from '../types/auction.types';
import { AuctionAPI } from '../services/auctionAPI';
import { AIService } from '../services/aiService';

const aiService = new AIService();

export function useAuction() {
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [aiAgents, setAIAgents] = useState<AIAgent[]>([
    {
      id: 'ai_1',
      name: 'BidBot Alpha',
      strategyType: 'reinforcement_learning',
      budget: 5000,
      remainingBudget: 5000,
      valuationCap: 50000,
      totalSpent: 0,
      aggressionLevel: 0.6,
      isActive: true,
      config: { min_wait_time: 2, max_wait_time: 6 },
    },
    {
      id: 'ai_2',
      name: 'BidBot Beta',
      strategyType: 'reinforcement_learning',
      budget: 4000,
      remainingBudget: 4000,
      valuationCap: 10000,
      totalSpent: 0,
      aggressionLevel: 0.4,
      isActive: true,
      config: { min_wait_time: 3, max_wait_time: 8 },
    },
  ]);
  const [loading, setLoading] = useState(true);

  const refreshAuctions = useCallback(async () => {
    setLoading(true);
    const fetchedAuctions = await AuctionAPI.fetchAuctions();
    setAuctions(fetchedAuctions);
    setLoading(false);
  }, []);

  const createAuction = useCallback(async (auctionData: Omit<Auction, 'id' | 'bids' | 'participants' | 'status'>) => {
    const success = await AuctionAPI.createAuction(auctionData);
    if (success) {
      await refreshAuctions();
    }
    return success;
  }, [refreshAuctions]);

  const startAuction = useCallback(async (auctionId: string, selectedAgents: string[]) => {
    const success = await AuctionAPI.startAuction(auctionId);
    if (success) {
      const auction = auctions.find(a => a.id === auctionId);
      if (auction) {
        const participatingAgents = aiAgents.filter(agent => selectedAgents.includes(agent.id));

        aiService.startBidding(
          auction,
          participatingAgents,
          async (bid: Bid) => {
            const result = await AuctionAPI.placeBid(auctionId, bid);
            if (result.success) {
              await refreshAuctions();
            }
          }
        );
      }
      await refreshAuctions();
    }
    return success;
  }, [auctions, aiAgents, refreshAuctions]);

  const placeBid = useCallback(async (auctionId: string, bid: Bid) => {
    return await AuctionAPI.placeBid(auctionId, bid);
  }, []);

  const stopAllAI = useCallback(() => {
    aiService.stopAllBidding();
  }, []);

  useEffect(() => {
    refreshAuctions();
  }, [refreshAuctions]);

  return {
    auctions,
    aiAgents,
    loading,
    createAuction,
    startAuction,
    placeBid,
    refreshAuctions,
    stopAllAI,
  };
}