export type AuctionFormat = 'english' | 'dutch' | 'first_price_sealed' | 'vickrey';
export type AuctionStatus = 'pending' | 'active' | 'completed' | 'cancelled';
export type BidderType = 'human' | 'ai';
export type StrategyType = 'heuristic' | 'reinforcement_learning';

export interface Auction {
  id: string;
  title: string;
  description: string;
  format: string; // optional, in case you want different auction styles later
  startingPrice: number;
  reservePrice: number;
  increment: number;
  startTime: number;
  endTime: number;
  currentPrice: number;
  status: 'pending' | 'active' | 'completed';
  winnerId?: string;
  winnerName?: string;
  winnerType?: string;
  winningPrice?: number;
  bids: Bid[];
  participants: Set<string>;
}



export interface Bid {
  id: string;
  auctionId: string;
  bidderId: string;
  bidderName: string;
  bidderType: 'ai' | 'human';
  amount: number;
  timestamp: number;
}


export interface AIAgent {
  id: string;
  name: string;
  strategyType: StrategyType;
  budget: number;
  remainingBudget: number;
  valuationCap: number;
  aggressionLevel: number;
  isActive: boolean;
  config: Record<string, any>;
  totalSpent: number;
}

export interface HumanParticipant {
  id: string;
  name: string;
  balance: number;
}
