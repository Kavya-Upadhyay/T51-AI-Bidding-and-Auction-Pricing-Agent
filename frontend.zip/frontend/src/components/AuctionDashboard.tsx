// src/components/AuctionDashboard.tsx
import React from 'react';
import { useAuction } from '../hooks/useAuction';
import { Auction } from '../types/auction.types';
import { Clock, Users, TrendingUp, DollarSign } from 'lucide-react';

interface AuctionDashboardProps {
  onSelectAuction: (auction: Auction) => void;
}

export function AuctionDashboard({ onSelectAuction }: AuctionDashboardProps) {
  const { auctions, loading } = useAuction();

  const formatTimeRemaining = (endTime: number) => {
    const remaining = Math.max(0, endTime - Date.now());
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  const statusColors = {
    pending: 'bg-gray-100 text-gray-800',
    active: 'bg-green-100 text-green-800',
    completed: 'bg-blue-100 text-blue-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">Loading auctions...</div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Auctions</h3>

      {auctions.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No auctions available. Create one to get started!
        </div>
      ) : (
        <div className="grid gap-4">
          {auctions.map(auction => (
            <div
              key={auction.id}
              onClick={() => onSelectAuction(auction)}
              className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all cursor-pointer hover:border-blue-300"
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-gray-900">{auction.title}</h4>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[auction.status]}`}>
                  {auction.status}
                </span>
              </div>

              <p className="text-sm text-gray-600 mb-3">{auction.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div className="flex items-center space-x-1">
                  <DollarSign className="h-4 w-4 text-gray-400" />
                  <span>${auction.currentPrice.toFixed(2)}</span>
                </div>

                <div className="flex items-center space-x-1">
                  <Users className="h-4 w-4 text-gray-400" />
                  <span>{auction.participants.size} participants</span>
                </div>

                <div className="flex items-center space-x-1">
                  <TrendingUp className="h-4 w-4 text-gray-400" />
                  <span>{auction.bids.length} bids</span>
                </div>

                {auction.status === 'active' && (
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span>{formatTimeRemaining(auction.endTime)}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}