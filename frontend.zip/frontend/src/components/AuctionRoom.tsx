// src/components/AuctionRoom.tsx
import React, { useState, useEffect } from 'react';
import { useAuction } from '../hooks/useAuction';
import { useAuth } from '../contexts/AuthContext';
import { Auction, Bid } from '../types/auction.types';
import { X, Clock, Bot, User, DollarSign } from 'lucide-react';

interface AuctionRoomProps {
  auction: Auction;
  onClose: () => void;
}

export function AuctionRoom({ auction, onClose }: AuctionRoomProps) {
  const { profile } = useAuth();
  const { aiAgents, placeBid, startAuction } = useAuction();
  const [bidAmount, setBidAmount] = useState('');
  const [selectedAgents, setSelectedAgents] = useState<string[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const isParticipant = profile ? auction.participants.has(profile.id) : false;
  const userBalance = profile?.balance || 0;

  useEffect(() => {
    if (auction.status === 'active') {
      const interval = setInterval(() => {
        setTimeRemaining(Math.max(0, auction.endTime - Date.now()));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [auction.status, auction.endTime]);

  useEffect(() => {
    if (auction.status === 'pending') {
      setSelectedAgents(aiAgents.slice(0, 2).map(a => a.id));
    }
  }, [auction.status, aiAgents]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handlePlaceBid = async () => {
    const amount = parseFloat(bidAmount);

    if (isNaN(amount)) {
      setMessage({ type: 'error', text: 'Please enter a valid amount' });
      return;
    }

    if (amount > userBalance) {
      setMessage({ type: 'error', text: 'Insufficient balance' });
      return;
    }

    if (amount < auction.currentPrice + auction.increment) {
      setMessage({ type: 'error', text: `Minimum bid is $${(auction.currentPrice + auction.increment).toFixed(2)}` });
      return;
    }

    if (!profile) return;

    const bid: Bid = {
      id: `bid-${profile.id}-${Date.now()}`,
      auctionId: auction.id,
      bidderId: profile.id,
      bidderType: 'human',
      bidderName: profile.display_name,
      amount,
      timestamp: Date.now()
    };

    const result = await placeBid(auction.id, bid);
    setMessage({ type: result.success ? 'success' : 'error', text: result.message });

    if (result.success) {
      setBidAmount('');
    }
  };

  const handleStartAuction = async () => {
    const success = await startAuction(auction.id, selectedAgents);
    if (success) {
      setMessage({ type: 'success', text: 'Auction started!' });
    }
  };

  const sortedBids = [...auction.bids].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">{auction.title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Auction Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">${auction.currentPrice.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Current Price</div>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{auction.bids.length}</div>
              <div className="text-sm text-gray-600">Total Bids</div>
            </div>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{auction.participants.size}</div>
              <div className="text-sm text-gray-600">Participants</div>
            </div>

            {auction.status === 'active' && (
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600 flex items-center justify-center">
                  <Clock className="h-6 w-6 mr-2" />
                  {formatTime(timeRemaining)}
                </div>
                <div className="text-sm text-gray-600">Time Left</div>
              </div>
            )}
          </div>

          {/* Pending State - AI Selection */}
          {auction.status === 'pending' && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Select AI Competitors</h3>
              <div className="space-y-2 mb-4">
                {aiAgents.map(agent => (
                  <label key={agent.id} className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={selectedAgents.includes(agent.id)}
                      onChange={() => {
                        setSelectedAgents(prev => 
                          prev.includes(agent.id) 
                            ? prev.filter(id => id !== agent.id)
                            : [...prev, agent.id]
                        );
                      }}
                      className="w-4 h-4 text-blue-600 rounded"
                    />
                    <span className="font-medium">{agent.name}</span>
                    <span className="text-sm text-gray-600">
                      Budget: ${agent.budget.toLocaleString()}
                    </span>
                  </label>
                ))}
              </div>

              <button
                onClick={handleStartAuction}
                className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700"
              >
                Start Auction with {selectedAgents.length} AI Agent{selectedAgents.length !== 1 ? 's' : ''}
              </button>
            </div>
          )}

          {/* Active State - Bidding */}
          {auction.status === 'active' && isParticipant && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Place Your Bid</h3>
              <div className="flex space-x-2">
                <input
                  type="number"
                  value={bidAmount}
                  onChange={(e) => setBidAmount(e.target.value)}
                  placeholder={`Min: $${(auction.currentPrice + auction.increment).toFixed(2)}`}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={handlePlaceBid}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
                >
                  Place Bid
                </button>
              </div>

              <div className="flex space-x-2 mt-2">
                <button
                  onClick={() => setBidAmount((auction.currentPrice + auction.increment).toFixed(2))}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
                >
                  Min Bid: ${(auction.currentPrice + auction.increment).toFixed(2)}
                </button>
                <button
                  onClick={() => setBidAmount((auction.currentPrice + auction.increment * 5).toFixed(2))}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
                >
                  +5x: ${(auction.currentPrice + auction.increment * 5).toFixed(2)}
                </button>
              </div>
            </div>
          )}

          {/* Completed State */}
          {auction.status === 'completed' && auction.winnerId && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
              <h3 className="text-xl font-semibold text-green-800 mb-2">Auction Completed!</h3>
              <div className="text-lg">
                Winner: <span className="font-bold">{auction.winnerName}</span>
              </div>
              <div className="text-2xl font-bold text-green-600 mt-2">
                ${auction.winningPrice?.toFixed(2)}
              </div>
            </div>
          )}

          {/* Message */}
          {message && (
            <div className={`p-3 rounded-lg ${
              message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {message.text}
            </div>
          )}

          {/* Bid History */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Bid History</h3>
            {sortedBids.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {sortedBids.map((bid, index) => (
                  <div key={bid.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      {bid.bidderType === 'ai' ? (
                        <Bot className="h-5 w-5 text-blue-600" />
                      ) : (
                        <User className="h-5 w-5 text-green-600" />
                      )}
                      <span className="font-medium">{bid.bidderName}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="font-bold text-green-600">${bid.amount.toFixed(2)}</span>
                      <span className="text-sm text-gray-500">
                        {new Date(bid.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No bids yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}