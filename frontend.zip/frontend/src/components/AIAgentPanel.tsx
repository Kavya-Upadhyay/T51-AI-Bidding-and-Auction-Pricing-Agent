// src/components/AIAgentPanel.tsx
import React from 'react';
import { AIAgent } from '../types/auction.types';
import { Bot, TrendingUp, DollarSign, Zap } from 'lucide-react';

interface AIAgentPanelProps {
  agents: AIAgent[];
}

export function AIAgentPanel({ agents }: AIAgentPanelProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Bot className="h-6 w-6 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900">AI Agents</h3>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-gray-900">{agent.name}</h4>
              <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                agent.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
              }`}>
                {agent.isActive ? 'Active' : 'Inactive'}
              </div>
            </div>

            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <TrendingUp className="h-4 w-4" />
                <span>Strategy: {agent.strategyType.replace('_', ' ')}</span>
              </div>

              <div className="flex items-center space-x-1">
                <DollarSign className="h-4 w-4" />
                <span>Budget: ${agent.remainingBudget.toLocaleString()} / ${agent.budget.toLocaleString()}</span>
              </div>

              <div className="flex items-center space-x-1">
                <Zap className="h-4 w-4" />
                <span>Aggression: {Math.round(agent.aggressionLevel * 100)}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}