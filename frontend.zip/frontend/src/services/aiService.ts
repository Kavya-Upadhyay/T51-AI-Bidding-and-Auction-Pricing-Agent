// src/services/aiService.ts
import { Auction, AIAgent, Bid } from '../types/auction.types';
import { AuctionAPI } from './auctionAPI';

export class AIService {
  private activeBidders: Map<string, NodeJS.Timeout> = new Map();

  startBidding(
    auction: Auction,
    agents: AIAgent[],
    onBid: (bid: Bid) => void
  ): void {
    if (!auction || agents.length === 0) return;

    agents.forEach((agent) => {
      const interval = setInterval(async () => {
        if (auction.status !== 'active' || agent.remainingBudget <= 0) {
          this.stopBidding(agent.id);
          return;
        }

        const auctionState = {
          current_price: auction.currentPrice,
          increment: auction.increment,
          remaining_budget: agent.remainingBudget,
          time_left: auction.endTime - Date.now(),
        };

        const bidAmount = await AuctionAPI.requestAIBid(agent.id, auctionState);

        if (bidAmount && bidAmount > auction.currentPrice) {
          const bid: Bid = {
            id: `bid-${agent.id}-${Date.now()}`,
            auctionId: auction.id,
            bidderId: agent.id,
            bidderType: 'ai',
            bidderName: agent.name,
            amount: bidAmount,
            timestamp: Date.now()
          };

          onBid(bid);
        }
      }, this.randomBetween(3000, 7000));

      this.activeBidders.set(agent.id, interval);
    });
  }

  stopBidding(agentId: string): void {
    const interval = this.activeBidders.get(agentId);
    if (interval) {
      clearInterval(interval);
      this.activeBidders.delete(agentId);
    }
  }

  stopAllBidding(): void {
    this.activeBidders.forEach((interval) => clearInterval(interval));
    this.activeBidders.clear();
  }

  private randomBetween(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}