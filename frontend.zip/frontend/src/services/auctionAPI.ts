// src/services/auctionAPI.ts
import { Auction, Bid } from '../types/auction.types';

const API_BASE = 'http://127.0.0.1:5000/api/auction';

export class AuctionAPI {
  static async fetchAuctions(): Promise<Auction[]> {
    try {
      const res = await fetch(`${API_BASE}/get-auction`);
      const data = await res.json();

      if (res.ok && Array.isArray(data.auctions)) {
        return data.auctions.map((a: any) => ({
          ...a,
          participants: new Set(a.participants || []),
        }));
      }
      return [];
    } catch (err) {
      console.error('Failed to fetch auctions:', err);
      return [];
    }
  }

  static async createAuction(auction: Omit<Auction, 'id' | 'bids' | 'participants' | 'status'>): Promise<boolean> {
    try {
      const payload = {
        ...auction,
        id: crypto.randomUUID(),
        bids: [],
        participants: [],
        status: 'pending'
      };

      const res = await fetch(`${API_BASE}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      return res.ok;
    } catch (err) {
      console.error('Error creating auction:', err);
      return false;
    }
  }

  static async startAuction(auctionId: string): Promise<boolean> {
    try {
      const res = await fetch(`${API_BASE}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ auction_id: auctionId }),
      });
      return res.ok;
    } catch (err) {
      console.error('Error starting auction:', err);
      return false;
    }
  }

  static async placeBid(auctionId: string, bid: Bid): Promise<{ success: boolean; message: string }> {
    try {
      const res = await fetch(`${API_BASE}/place-bid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          auction_id: auctionId,
          bidder_id: bid.bidderId,
          amount: bid.amount,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to place bid' };
      }

      return { success: true, message: 'Bid placed successfully' };
    } catch (err) {
      console.error('Error placing bid:', err);
      return { success: false, message: 'Network error' };
    }
  }

  static async requestAIBid(agentId: string, auctionState: any): Promise<number | null> {
    try {
      const res = await fetch(`${API_BASE}/ai-bid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_id: agentId,
          auction_state: auctionState,
        }),
      });

      const data = await res.json();
      return res.ok && data?.bid_amount ? data.bid_amount : null;
    } catch (err) {
      console.error('AI bid request failed:', err);
      return null;
    }
  }
}