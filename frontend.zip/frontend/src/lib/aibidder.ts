// File: src/lib/aiBidder.ts
import { Auction, AIAgent, Bid } from '../types/auction';

const API_BASE = 'http://127.0.0.1:5000/api/auction';

export class AIBidder {
  
  private activeBidders: Map<string, NodeJS.Timeout> = new Map();

  /**
   * Starts AI bidding loop for given auction using backend RL agents.
   * @param auction Auction object
   * @param agents List of AI agents participating
   * @param onBid Callback for when an AI agent places a bid
   */
  startBidding(
    auction: Auction,
    agents: AIAgent[],
    onBid: (bid: Bid) => void
  ) {
    if (!auction || agents.length === 0) return;

    agents.forEach((agent) => {
      const interval = setInterval(async () => {
        if (auction.status !== 'active') {
          clearInterval(interval);
          return;
        }

        // Stop if budget exhausted
        if (agent.remainingBudget <= 0) {
          clearInterval(interval);
          return;
        }

        // Prepare state for backend RL model
        const auctionState = {
          current_price: auction.currentPrice,
          increment: auction.increment,
          remaining_budget: agent.remainingBudget,
          time_left: auction.endTime - Date.now(),
        };

        try {
          // 🔥 Ask backend DQN agent to decide the bid
          const res = await fetch(`${API_BASE}/ai-bid`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              agent_id: agent.id,
              auction_state: auctionState,
            }),
          });

          const data = await res.json();
          if (!res.ok || !data || !data.bid_amount) return;

          const bidAmount = data.bid_amount;
          if (bidAmount <= auction.currentPrice) return;

          // Construct bid
          const bid: Bid = {
            id: `bid-${agent.id}-${Date.now()}`,
            auctionId: auction.id,
            bidderId: agent.id,
            bidderType: 'ai',
            bidderName: agent.name,
            amount: bidAmount,
            timestamp: Date.now()
          };

          // Callback to AuctionContext → engine.placeBid()
          onBid(bid);
        } catch (err) {
          console.error(`AI Bidder (${agent.name}) failed to bid:`, err);
        }
      }, this.randomBetween(3000, 7000)); // 3–7 sec bidding interval

      this.activeBidders.set(agent.id, interval);
    });
  }

  /** Stop all AI bidding loops */
  stopAllBidding() {
    this.activeBidders.forEach((interval) => clearInterval(interval));
    this.activeBidders.clear();
  }

  /** Helper for randomized timing */
  private randomBetween(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
