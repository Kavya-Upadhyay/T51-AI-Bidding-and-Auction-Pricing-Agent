import { Auction, Bid } from '../types/auction';

const API_BASE = 'http://127.0.0.1:5000/api/auction';

export class AuctionEngine {
  private auctions: Map<string, Auction> = new Map();
  private timers: Map<string, NodeJS.Timeout> = new Map();

  // Create a new auction (locally + backend)
  async createAuction(auction: Auction): Promise<void> {
    this.auctions.set(auction.id, auction);

    await fetch(`${API_BASE}/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(auction),
    });
  }

  // Get auction state (from backend if possible)
  async getAuction(id: string): Promise<Auction | undefined> {
    try {
      const res = await fetch(`${API_BASE}/get-auction`);
      const data = await res.json();
      if (data.state) return data.state as Auction;
    } catch (err) {
      console.warn('⚠ Backend not reachable, using local data.');
    }
    return this.auctions.get(id);
  }

  getAllAuctions(): Auction[] {
    return Array.from(this.auctions.values());
  }

  // Start auction locally
  startAuction(auctionId: string, onUpdate: (auction: Auction) => void): void {
    const auction = this.auctions.get(auctionId);
    if (!auction) return;

    auction.status = 'active';
    onUpdate(auction);

    const timer = setTimeout(() => {
      this.endAuction(auctionId, onUpdate);
    }, auction.endTime - Date.now());

    this.timers.set(auctionId, timer);
  }

  // Place bid (validates locally, confirms via backend)
  async placeBid(
    auctionId: string,
    bid: Bid,
    onUpdate: (auction: Auction) => void
  ): Promise<{ success: boolean; message: string }> {
    const auction = this.auctions.get(auctionId);
    if (!auction) {
      return { success: false, message: 'Auction not found' };
    }

    if (auction.status !== 'active') {
      return { success: false, message: 'Auction is not active' };
    }

    if (bid.amount < auction.currentPrice + auction.increment) {
      return {
        success: false,
        message: `Bid must be at least ${auction.currentPrice + auction.increment}`,
      };
    }

    try {
      const res = await fetch(`${API_BASE}/place-bid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_id: bid.bidderId,
          bid_amount: bid.amount,
        }),
      });

      const result = await res.json();

      if (result.error) {
        return { success: false, message: result.error };
      }

      auction.currentPrice = bid.amount;
      auction.bids.push(bid);
      onUpdate(auction);

      return { success: true, message: 'Bid placed successfully' };
    } catch (err) {
      return { success: false, message: 'Backend unreachable. Try again.' };
    }
  }

  // End auction locally and determine winner
  private endAuction(auctionId: string, onUpdate: (auction: Auction) => void): void {
    const auction = this.auctions.get(auctionId);
    if (!auction || auction.status !== 'active') return;

    auction.status = 'completed';

    const timer = this.timers.get(auctionId);
    if (timer) {
      clearTimeout(timer);
      this.timers.delete(auctionId);
    }

    this.determineWinner(auction);
    onUpdate(auction);
  }

  // Determine winner for English auction
  private determineWinner(auction: Auction): void {
    if (auction.bids.length === 0) return;

    const highestBid = auction.bids.reduce((max, bid) =>
      bid.amount > max.amount ? bid : max
    );

    auction.winnerId = highestBid.bidderId;
    auction.winnerType = highestBid.bidderType;
    auction.winnerName = highestBid.bidderName;
    auction.winningPrice = highestBid.amount;
  }

  joinAuction(auctionId: string, participantId: string): void {
    const auction = this.auctions.get(auctionId);
    if (auction) {
      auction.participants.add(participantId);
    }
  }

  cleanup(): void {
    this.timers.forEach((timer) => clearTimeout(timer));
    this.timers.clear();
  }
}
